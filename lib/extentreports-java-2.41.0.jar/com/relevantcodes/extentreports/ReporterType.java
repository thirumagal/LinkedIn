package com.relevantcodes.extentreports;

public enum ReporterType {
	DB
}
